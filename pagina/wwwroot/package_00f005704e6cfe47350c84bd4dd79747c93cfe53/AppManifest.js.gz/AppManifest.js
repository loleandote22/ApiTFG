var UnoAppManifest = {
    displayName: "AplicacionTFG",
    splashScreenImage: "splash_screen.scale-200.png",
    splashScreenColor: "#ffffff",
}